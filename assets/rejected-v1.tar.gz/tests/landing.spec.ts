import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('desktop navigation, colorways, demo form and accessibility', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await expect(page).toHaveTitle(/VANTA/);
  await page.screenshot({ path: 'test-results/desktop-hero.png' });
  await page.getByRole('link', { name: 'Phối màu', exact: true }).click();
  for (const name of ['Carbon', 'Clay', 'Chalk']) {
    await page.getByRole('button', { name, exact: true }).click();
    await expect(page.getByRole('button', { name, exact: true })).toHaveAttribute('aria-pressed', 'true');
    await expect(page.getByAltText(`FORM 01 phối màu ${name}`)).toBeVisible();
  }
  await page.getByLabel('Email của bạn').fill('not-email');
  await page.getByRole('button', { name: 'Đăng ký ↗', exact: true }).click();
  await expect(page.getByRole('status')).toBeEmpty();
  await page.getByLabel('Email của bạn').fill('demo@example.com');
  await page.getByRole('button', { name: 'Đăng ký ↗', exact: true }).click();
  await expect(page.getByRole('status')).toContainText('Email không được lưu hay gửi đi');
  expect((await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()).violations).toEqual([]);
  expect(errors).toEqual([]);
});

test('mobile fits and reduced motion avoids pinning', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await expect(page.locator('.pin-spacer')).toHaveCount(0);
  await page.screenshot({ path: 'test-results/mobile-hero.png' });
  await page.screenshot({ path: 'test-results/mobile-full.png', fullPage: true });
  expect((await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()).violations).toEqual([]);
});

test('3D loads and static view is recoverable', async ({ page }) => {
  await page.goto('/');
  const model = page.waitForResponse(response => response.url().endsWith('/models/form-01.glb'));
  await page.getByRole('button', { name: 'Khám phá 3D ↗' }).click();
  expect((await model).status()).toBe(200);
  await expect(page.locator('canvas')).toBeVisible();
  await page.getByLabel('Xoay góc nhìn').fill('1');
  await page.screenshot({ path: 'test-results/viewer.png' });
  await page.getByRole('button', { name: 'Xem ảnh tĩnh', exact: true }).click();
  await expect(page.locator('canvas')).toHaveCount(0);
  await expect(page.getByAltText('Cấu trúc sneaker FORM 01')).not.toHaveClass(/dimmed/);
});

test('failed model request provides recovery', async ({ page }) => {
  await page.route('**/models/form-01.glb', route => route.abort());
  await page.goto('/');
  await page.getByRole('button', { name: 'Khám phá 3D ↗' }).click();
  await expect(page.getByText('3D chưa khả dụng.', { exact: false })).toBeVisible();
  await page.getByRole('button', { name: 'Xem ảnh tĩnh', exact: true }).click();
  await expect(page.getByAltText('Cấu trúc sneaker FORM 01')).not.toHaveClass(/dimmed/);
});

test('desktop motion pins the story and removes pinning for reduced motion', async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  await expect(page.locator('.pin-spacer')).toHaveCount(1);
  await page.getByRole('button', { name: 'Khám phá 3D ↗' }).click();
  await expect(page.locator('canvas')).toBeVisible();
  const start = await page.locator('#thiet-ke').evaluate(element => element.getBoundingClientRect().top + scrollY);
  await page.evaluate(y => window.scrollTo({ top: y + 350, behavior: 'instant' }), start);
  await expect.poll(async () => Number(await page.getByLabel('Xoay góc nhìn').inputValue())).toBeGreaterThan(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await expect(page.locator('.pin-spacer')).toHaveCount(0);
});
