'use client';
import { useState } from 'react';
import Image from 'next/image';
const colors = [{id:'chalk',name:'Chalk',hex:'#ddd5c3',text:'Sắc kem. Nét đen. Một điểm cam.'},{id:'carbon',name:'Carbon',hex:'#30343b',text:'Trầm sắc. Rõ cá tính.'},{id:'clay',name:'Clay',hex:'#a7805e',text:'Tông đất. Một nhịp điệu khác.'}];
export default function Colorways() {
  const [selected,setSelected]=useState(0); const color=colors[selected];
  return <section id="phoi-mau" className="color-section"><div className="section-top"><span>FORM 01 / Color study</span><span>Ba sắc thái. Một tinh thần.</span></div><div className="color-grid"><div className="color-visual" style={{background:selected===1?'#c2c1ba':selected===2?'#d7bea2':'#e7e1d5'}}><span className="color-word" aria-hidden="true">{color.name}</span><Image src={`/images/${color.id}.webp`} width={1600} height={1000} alt={`FORM 01 phối màu ${color.name}`} sizes="(max-width:760px) 100vw, 60vw"/><span className="color-index">0{selected+1} / 03</span></div><div className="color-copy"><h2>CHỌN SẮC.<br/>GIỮ CHẤT.</h2><p>Mỗi ngày, một cách thể hiện. Tìm sắc thái thuộc về bạn.</p><div className="swatches" role="group" aria-label="Chọn phối màu">{colors.map((item,i)=><button key={item.id} aria-pressed={selected===i} onClick={()=>setSelected(i)}><span style={{background:item.hex}}/>{item.name}</button>)}</div><div aria-live="polite" className="color-description"><h3>{color.name}</h3><p>{color.text}</p></div><a href="#dang-ky" className="button dark">Theo dõi FORM 01 ↗</a></div></div></section>;
}
