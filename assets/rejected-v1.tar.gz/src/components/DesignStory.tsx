'use client';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import { Component,useEffect,useRef,useState,type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
const ShoeCanvas=dynamic(()=>import('./ShoeCanvas'),{ssr:false,loading:()=> <p className="viewer-message">Đang tải mô hình…</p>});
class ViewerBoundary extends Component<{children:ReactNode},{failed:boolean}>{state={failed:false};static getDerivedStateFromError(){return {failed:true};}render(){return this.state.failed?<p className="viewer-message">3D chưa khả dụng. Chọn “Xem ảnh tĩnh” để tiếp tục.</p>:this.props.children;}}
export default function DesignStory(){
 const root=useRef<HTMLElement>(null);const [active,setActive]=useState(false);const [angle,setAngle]=useState(-.35);
 useEffect(()=>{gsap.registerPlugin(ScrollTrigger);const media=gsap.matchMedia();media.add('(min-width:900px) and (prefers-reduced-motion:no-preference)',()=>{const rotation={value:-.35};gsap.to(rotation,{value:2.8,ease:'none',onUpdate:()=>setAngle(rotation.value),scrollTrigger:{trigger:root.current,start:'top top',end:'+=750',pin:true,scrub:.8}});});return()=>media.revert();},[]);
 return <section id="thiet-ke" ref={root} className="story"><div className="section-top"><span>Một góc nhìn mới</span><span>VANTA Design Studio</span></div><h2>KHÁC BIỆT TỪ<br/>MỌI GÓC NHÌN.</h2><div className="story-stage"><span className="story-watermark" aria-hidden="true">FORM 01</span><Image src="/images/chalk.webp" width={1600} height={1000} alt="Cấu trúc sneaker FORM 01" sizes="(max-width:760px) 100vw, 75vw" className={active?'story-poster dimmed':'story-poster'}/>{active&&<div className="canvas-layer" role="img" aria-label="Mô hình 3D sneaker FORM 01"><ViewerBoundary><ShoeCanvas angle={angle}/></ViewerBoundary></div>}</div><div className="story-bottom"><p>Đường nét có chủ đích.<br/>Cá tính không cần phô trương.</p><div className="viewer-controls">{!active?<button className="button outline" onClick={()=>setActive(true)}>Khám phá 3D ↗</button>:<><label htmlFor="rotation">Xoay góc nhìn</label><input id="rotation" type="range" min="-3.14" max="3.14" step=".02" value={angle} onChange={e=>setAngle(Number(e.target.value))}/><button className="text-button" onClick={()=>setActive(false)}>Xem ảnh tĩnh</button></>}</div></div></section>;
}
