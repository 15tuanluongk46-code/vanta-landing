import Image from 'next/image';
import Hero from '@/components/Hero';
import DesignStory from '@/components/DesignStory';
import Colorways from '@/components/Colorways';
import Signup from '@/components/Signup';

const details = [
  { title: 'Những lớp tương phản', text: 'Mảng màu kem và đường viền tối tạo nhịp điệu cho thân giày.', view: 'upper' },
  { title: 'Một điểm nhấn riêng', text: 'Quai gót màu cam. Chi tiết nhỏ, dấu ấn rõ ràng.', view: 'heel' },
  { title: 'Dáng đế phân tầng', text: 'Các lớp đế tiếp nối đường nét, định hình silhouette.', view: 'sole' },
];

export default function Home() {
  return (
    <>
      <a className="skip-link" href="#main">Đến nội dung chính</a>
      <header className="header">
        <a href="#" className="wordmark" aria-label="VANTA trang đầu">VANTA<span>®</span></a>
        <nav aria-label="Điều hướng chính">
          <a href="#thiet-ke">Thiết kế</a>
          <a href="#phoi-mau">Phối màu</a>
          <a href="#lookbook">Lookbook</a>
        </nav>
        <a href="#dang-ky" className="nav-cta">Đón FORM 01 ↗</a>
      </header>
      <main id="main">
        <Hero />
        <div className="brand-strip">
          <span>YOUR PACE.</span><span className="asterisk" aria-hidden="true">✳</span>
          <span>YOUR SPACE.</span><span className="asterisk" aria-hidden="true">✳</span>
          <span>YOUR FORM.</span>
        </div>
        <DesignStory />
        <section className="lookbook" id="lookbook">
          <div className="lookbook-copy">
            <span>Form follows you.</span>
            <h2>XUỐNG PHỐ.<br />THEO CÁCH<br />CỦA BẠN.</h2>
            <p>Từ một con phố quen đến một lối rẽ mới. FORM 01 là lời mời thể hiện mình, trong từng lựa chọn mỗi ngày.</p>
            <a href="#phoi-mau" className="text-link">Tìm phối màu của bạn ↗</a>
          </div>
          <div className="lookbook-art">
            <span className="lookbook-type" aria-hidden="true">OFF<br />SCRIPT.</span>
            <Image src="/images/clay.webp" alt="FORM 01 Clay — nghiên cứu phối màu tông đất" width={1600} height={1000} sizes="(max-width:760px) 100vw, 55vw" />
            <span className="art-caption">Studio study / Clay edition</span>
          </div>
        </section>
        <section className="details">
          <div className="details-heading">
            <h2>CHI TIẾT TẠO NÊN<br />KHÁC BIỆT.</h2>
            <p>Ngôn ngữ thiết kế của FORM 01.<br />Ít hơn. Nhưng không nhạt hơn.</p>
          </div>
          <div className="detail-grid">
            {details.map(item => (
              <article key={item.view}>
                <div className="detail-image macro">
                  <Image src={`/images/detail-${item.view}.webp`} alt={`Chi tiết ${item.title.toLowerCase()} của FORM 01`} width={1000} height={800} sizes="(max-width:760px) 90vw, 30vw" />
                </div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>
        <Colorways />
        <Signup />
      </main>
      <footer className="footer">
        <a href="#" className="footer-logo" aria-label="VANTA về đầu trang">VANTA</a>
        <div className="footer-bottom">
          <span>© 2026 VANTA Design Concept</span>
          <p>Thương hiệu và sản phẩm hư cấu. Website concept, không bán hàng hoặc thu thập email.</p>
          <a href="#">Về đầu trang ↑</a>
        </div>
      </footer>
    </>
  );
}
