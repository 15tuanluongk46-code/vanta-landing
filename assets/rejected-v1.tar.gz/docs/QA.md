# Verification — 2026-10-04

## Kết quả đã chạy

| Check | Kết quả |
|---|---|
| `npm run lint` | PASS |
| `npm run typecheck` | PASS |
| `npm run build` | PASS — Next.js production build |
| `npm test` | PASS — 5 Playwright tests |
| Lighthouse mobile, production | Performance 95 / Accessibility 100; LCP khoảng 2.9 s |

Lighthouse là số đo local của một lần chạy, không bảo đảm điểm tương đương trên hosting hoặc thiết bị khác. Mục tiêu đặt ra: Performance ≥85, Accessibility ≥95. Báo cáo JSON máy hiện tại: `/tmp/opencode/vanta-lighthouse.json`.

Lệnh đã dùng:

```bash
CHROME_PATH=/home/sss/.local/bin/google-chrome npx lighthouse http://localhost:3017 --chrome-flags='--headless --no-sandbox' --only-categories=performance,accessibility --output=json --output-path=/tmp/opencode/vanta-lighthouse.json --quiet
```

## Phạm vi test tự động

1. Desktop: điều hướng phối màu, ba trạng thái lựa chọn/ảnh; email sai bị từ chối, email hợp lệ hiện thông báo demo; không pageerror; axe WCAG 2A/AA và 2.1AA không báo violation.
2. Mobile 390×844: không overflow ngang; reduced motion không tạo pin; axe không báo violation.
3. GLB trả HTTP 200, canvas hiện, thanh xoay thao tác được, trở lại poster.
4. Request GLB bị abort: hiện thông báo recovery và khôi phục poster được.
5. Desktop 1440×1000 với motion: có pin, cuộn thay góc nhìn, không overflow; đổi sang reduced motion gỡ pin.

## Kiểm tra hình ảnh

Hero desktop và mobile đã được xem qua Vision: sneaker nổi bật, headline/CTA đọc được, không ghi nhận clipping rõ ràng. Đây không phải kiểm chứng mọi pixel hoặc mọi trình duyệt. Screenshot được test tạo tại `test-results/desktop-hero.png`, `mobile-hero.png`, `mobile-full.png`, `viewer.png`.

## Giới hạn còn lại

- Lookbook chưa tích hợp ảnh lifestyle image_gen vì chưa nhận được đường dẫn tệp; hiện dùng studio render Clay.
- Detail cards đã có ba render macro riêng (upper/heel/sole), được Vision kiểm tra không thấy lỗi hình học/đen/magenta nghiêm trọng.
- GLB viewer màu Chalk; chọn phối màu cập nhật ảnh 2D.
- Chưa test Safari/iOS thật hoặc GPU điện thoại thật. Chromium chạy headless có software WebGL.
- Test recovery mô phỏng lỗi tải GLB; không mô phỏng mọi loại mất WebGL context.
- Không có backend gửi form; giao diện công khai trạng thái demo.

**Verdict:** các checks đã nêu đạt; phần asset lifestyle và kiểm thử thiết bị thật chưa hoàn tất.
