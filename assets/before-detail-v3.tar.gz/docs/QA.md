# Verification — Campaign V2

## Kết quả thực tế

| Check | Kết quả |
|---|---|
| `npm run lint` | PASS |
| `npm run typecheck` | PASS |
| `npm run build` | PASS — Next.js production build |
| `npm test` | PASS — 6 Playwright tests |
| Lighthouse mobile, production V2 | Performance 94 / Accessibility 100; LCP 2.9 s; CLS 0 |

Lighthouse là một lần đo local, không bảo đảm điểm tương đương trên hosting hoặc thiết bị khác. Mục tiêu Performance ≥85, Accessibility ≥95 đạt trong lần đo này.

```bash
CHROME_PATH=/home/sss/.local/bin/google-chrome npx lighthouse http://localhost:3017 --chrome-flags='--headless --no-sandbox' --only-categories=performance,accessibility --output=json --output-path=/tmp/opencode/vanta-v2-lighthouse.json --quiet
```

## Phạm vi kiểm thử

1. Desktop 1440×1000: điều hướng phối màu; ba trạng thái chọn/ảnh; CTA đến đúng `#dang-ky`; email sai bị từ chối; email hợp lệ hiện thông báo demo; không pageerror; axe WCAG 2A/AA và 2.1AA không báo violation.
2. Phone 360 và tablet 768: không overflow ngang, mọi anchor nội trang có đích tồn tại.
3. Mobile 390×844: không overflow, reduced motion không pin, axe không báo violation.
4. GLB HTTP 200, canvas hiện, thanh xoay hoạt động, trở lại poster được.
5. Request GLB bị abort: có recovery và trở về ảnh tĩnh.
6. Desktop có motion: không pin khi chưa bật 3D; pin sau khi bật; cuộn đổi góc nhìn; reduced motion gỡ pin.

## Kiểm tra thị giác

- Vision đã xem hero mobile và tablet: không ghi nhận headline/CTA bị giày che hoặc cắt rõ ràng.
- Vision đã xem thumbnail toàn trang desktop để đánh giá cách chia section; độ phân giải này không kiểm chứng chữ nhỏ.
- Campaign render đã được kiểm tra riêng: đôi giày rõ, tiếp xúc bục không ghi nhận xuyên hình rõ ràng.
- Screenshot: `test-results/desktop-hero.png`, `desktop-full.png`, `mobile-hero.png`, `mobile-full.png`, `layout-360.png`, `layout-768.png`, `viewer.png`.
- Kết quả kỹ thuật và nhận xét Vision không thay thế việc người dùng duyệt thẩm mỹ. V1 từng đạt kiểm thử nhưng bị người dùng từ chối; V2 không được ghi là đã được người dùng duyệt.

## Giới hạn

- Campaign studio, chưa có ảnh người mang giày/on-feet.
- GLB Chalk dùng vật liệu đơn giản; procedural texture V2 chưa bake sang model web.
- Chưa test Safari/iOS hoặc GPU điện thoại thật. Chromium headless có software WebGL.
- Recovery test mô phỏng lỗi tải GLB, không bao phủ mọi trường hợp mất WebGL context.
- Form demo không có backend, không gửi hoặc lưu email.

**Verdict:** kiểm thử kỹ thuật nêu trên đạt; bản thiết kế V2 sẵn sàng để người dùng đánh giá trực tiếp.
