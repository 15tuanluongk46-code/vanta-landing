'use client';

import Image from 'next/image';
import { useEffect, useRef } from 'react';
import gsap from 'gsap';

export default function Hero() {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    const media = gsap.matchMedia();
    media.add('(prefers-reduced-motion:no-preference)', () => {
      gsap.fromTo('.hero-shoe', { y: 24, rotation: -4 }, {
        y: 0, rotation: -10, duration: 1.3, ease: 'power3.out',
      });
    }, root);
    return () => media.revert();
  }, []);

  return (
    <section ref={root} className="hero" aria-labelledby="hero-title">
      <div className="hero-top"><span>VANTA / Independent footwear</span><span>Collection 2026</span></div>
      <div className="hero-copy">
        <p className="product-kicker">Introducing FORM 01</p>
        <h1 id="hero-title">ĐỊNH CHẤT<br />RIÊNG.</h1>
        <p className="hero-description">Một dáng giày quen.<br />Một cách thể hiện rất riêng.</p>
        <a className="button dark" href="#phoi-mau">Tìm phối màu của bạn <span aria-hidden="true">↗</span></a>
      </div>
      <div className="hero-art">
        <span className="hero-edition" aria-hidden="true">01</span>
        <Image className="hero-shoe" src="/images/hero-v2.webp" alt="VANTA FORM 01 — sneaker kem, viền đen và quai gót cam" width={1800} height={1200} sizes="(max-width:760px) 110vw, 70vw" preload />
        <div className="hero-spec"><span className="spec-line" /><span>FORM 01<br /><strong>Chalk / Orange accent</strong></span></div>
      </div>
      <div className="hero-bottom"><span>Không theo khuôn mẫu.</span><a href="#thiet-ke">Khám phá thiết kế <span aria-hidden="true">↓</span></a><span className="hero-index">Design study — 001</span></div>
    </section>
  );
}
