'use client';

import dynamic from 'next/dynamic';
import Image from 'next/image';
import { Component, useEffect, useRef, useState, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const ShoeCanvas = dynamic(() => import('./ShoeCanvas'), {
  ssr: false,
  loading: () => <p className="viewer-message">Đang tải mô hình…</p>,
});

class ViewerBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    return this.state.failed
      ? <p className="viewer-message" role="status">3D chưa khả dụng. Chọn “Xem ảnh tĩnh” để tiếp tục.</p>
      : this.props.children;
  }
}

export default function DesignStory() {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState(false);
  const [angle, setAngle] = useState(-.35);
  useEffect(() => {
    if (!active) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add('(min-width:900px) and (prefers-reduced-motion:no-preference)', () => {
      const rotation = { value: -.35 };
      gsap.to(rotation, {
        value: 2.8, ease: 'none', onUpdate: () => setAngle(rotation.value),
        scrollTrigger: { trigger: root.current, start: 'top top', end: '+=600', pin: true, scrub: .8 },
      });
    });
    return () => media.revert();
  }, [active]);

  return (
    <section id="thiet-ke" ref={root} className={`story${active ? ' is-active' : ''}`} aria-labelledby="story-title">
      <div className="story-copy">
        <span className="section-label">The design</span>
        <h2 id="story-title">QUEN DÁNG.<br />LẠ CHẤT.</h2>
        <p>Dáng low-top, những mảng màu đối lập và một nét cam ở gót. FORM 01 tìm sự khác biệt trong chính những điều giản đơn.</p>
        <div className="design-notes"><span>Layered silhouette</span><span>Signature heel tab</span><span>Three color expressions</span></div>
        <div className="viewer-controls">
          {!active ? <button className="button outline" onClick={() => setActive(true)}>Khám phá 3D <span aria-hidden="true">↗</span></button> : <>
            <label htmlFor="rotation">Xoay góc nhìn</label>
            <input id="rotation" type="range" min="-3.14" max="3.14" step=".02" value={angle} onChange={event => setAngle(Number(event.target.value))} />
            <button className="text-button" onClick={() => setActive(false)}>Xem ảnh tĩnh</button>
          </>}
        </div>
      </div>
      <div className="story-stage">
        <span className="stage-cross cross-top" aria-hidden="true">+</span>
        <span className="stage-cross cross-bottom" aria-hidden="true">+</span>
        <Image src="/images/hero-v2.webp" width={1800} height={1200} alt="Cấu trúc sneaker FORM 01" sizes="(max-width:760px) 100vw, 55vw" className={active ? 'story-poster dimmed' : 'story-poster'} />
        {active && <div className="canvas-layer" role="img" aria-label="Mô hình 3D sneaker FORM 01"><ViewerBoundary><ShoeCanvas angle={angle} /></ViewerBoundary></div>}
        <div className="stage-caption"><span>FORM 01 / Chalk</span><span>{active ? 'Interactive design study' : 'Explore every angle'}</span></div>
      </div>
    </section>
  );
}
