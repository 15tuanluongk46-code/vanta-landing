'use client';

import { useState } from 'react';
import Image from 'next/image';

const colors = [
  { id: 'chalk', name: 'Chalk', hex: '#ddd5c3', text: 'Sắc kem, nét đen và một điểm cam. Bản phối mở đầu câu chuyện FORM 01.' },
  { id: 'carbon', name: 'Carbon', hex: '#30343b', text: 'Những lớp sắc đen và xám. Một lựa chọn trầm, để đường nét lên tiếng.' },
  { id: 'clay', name: 'Clay', hex: '#a7805e', text: 'Nâu đất kết hợp kem ấm. Một góc nhìn mềm hơn trên cùng thiết kế.' },
];

export default function Colorways() {
  const [selected, setSelected] = useState(0);
  const color = colors[selected];
  return (
    <section id="phoi-mau" className="color-section" aria-labelledby="color-title">
      <div className="section-heading"><span className="section-label">The color edit</span><h2 id="color-title">CÙNG FORM.<br />KHÁC CHẤT.</h2><p>Ba bản phối.<br />Chọn cách bạn xuất hiện.</p></div>
      <div className="color-grid">
        <div className={`color-visual color-${color.id}`}>
          <span className="color-word" aria-hidden="true">{color.name}</span>
          <Image src={`/images/${color.id}.webp`} width={1800} height={1200} alt={`FORM 01 phối màu ${color.name}`} sizes="(max-width:760px) 100vw, 60vw" />
          <span className="color-index">FORM 01 — {color.name}</span>
        </div>
        <div className="color-copy">
          <p className="product-kicker">VANTA FORM 01</p>
          <div aria-live="polite" className="color-description"><h3>{color.name}</h3><p>{color.text}</p></div>
          <div className="swatches" role="group" aria-label="Chọn phối màu">{colors.map((item, i) => <button key={item.id} aria-pressed={selected === i} onClick={() => setSelected(i)}><span style={{ background: item.hex }} />{item.name}</button>)}</div>
          <dl className="product-facts"><div><dt>Dáng giày</dt><dd>Low-top</dd></div><div><dt>Bộ sưu tập</dt><dd>FORM 01</dd></div><div><dt>Trạng thái</dt><dd>Design concept</dd></div></dl>
          <a href="#dang-ky" className="button dark">Theo dõi FORM 01 <span aria-hidden="true">↗</span></a>
          <p className="availability">Sản phẩm concept. Chưa mở bán.</p>
        </div>
      </div>
    </section>
  );
}
