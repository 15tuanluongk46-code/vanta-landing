'use client';
import { Canvas, useLoader, useThree } from '@react-three/fiber';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Suspense, useEffect, useMemo } from 'react';
import { Box3, Vector3 } from 'three';
function Model({angle}:{angle:number}) {
  const gltf=useLoader(GLTFLoader,'/models/form-01.glb'); const invalidate=useThree(s=>s.invalidate);
  const scene=useMemo(()=>{ const copy=gltf.scene.clone(true); const center=new Box3().setFromObject(copy).getCenter(new Vector3()); copy.position.sub(center); return copy; },[gltf.scene]);
  useEffect(()=>{invalidate();},[angle,invalidate]);
  return <group rotation={[.08,angle,-.12]}><primitive object={scene}/></group>;
}
export default function ShoeCanvas({angle}:{angle:number}) { return <Canvas frameloop="demand" dpr={[1,1.5]} camera={{position:[-.13,.13,.43],fov:43}} gl={{alpha:true,antialias:true}} fallback={<p>3D chưa khả dụng. Bạn vẫn có thể xem ảnh sản phẩm.</p>}><ambientLight intensity={1.8}/><directionalLight position={[-2,4,3]} intensity={3}/><directionalLight position={[3,1,-2]} intensity={2}/><Suspense fallback={null}><Model angle={angle}/></Suspense></Canvas>; }
