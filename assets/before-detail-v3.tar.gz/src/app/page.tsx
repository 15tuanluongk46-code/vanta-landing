import Image from 'next/image';
import Hero from '@/components/Hero';
import DesignStory from '@/components/DesignStory';
import Colorways from '@/components/Colorways';
import Signup from '@/components/Signup';

const details = [
  { title: 'Những lớp tương phản', text: 'Mảng màu kem và đường viền tối tạo nhịp điệu cho thân giày.', view: 'upper' },
  { title: 'Một điểm nhấn riêng', text: 'Quai gót màu cam. Chi tiết nhỏ, dấu ấn rõ ràng.', view: 'heel' },
  { title: 'Dáng đế phân tầng', text: 'Các lớp đế tiếp nối đường nét, định hình silhouette.', view: 'sole' },
];

export default function Home() {
  return (
    <>
      <a className="skip-link" href="#main">Đến nội dung chính</a>
      <header className="header">
        <a href="#" className="wordmark" aria-label="VANTA trang đầu">VANTA<span className="brand-symbol" aria-hidden="true">✳</span></a>
        <nav aria-label="Điều hướng chính">
          <a href="#thiet-ke">Thiết kế</a>
          <a href="#phoi-mau">Phối màu</a>
          <a href="#lookbook">Campaign</a>
        </nav>
        <a href="#dang-ky" className="nav-cta">Đón FORM 01 ↗</a>
      </header>
      <main id="main">
        <Hero />
        <DesignStory />
        <section className="lookbook" id="lookbook">
          <div className="lookbook-copy">
            <span className="section-label">The campaign / Form & space</span>
            <h2>MỘT FORM.<br />KHÔNG<br />KHUÔN MẪU.</h2>
            <p>Đường nét của giày. Hình khối của không gian. Một cuộc đối thoại giữa những điều quen thuộc và góc nhìn của riêng bạn.</p>
            <a href="#phoi-mau" className="text-link">Tìm phối màu của bạn ↗</a>
            <span className="campaign-signature" aria-hidden="true">V / 01</span>
          </div>
          <div className="lookbook-art">
            <Image src="/images/campaign-v2.webp" alt="Hai chiếc FORM 01 Chalk trên các bệ kiến trúc màu cam trong studio" width={1600} height={1300} sizes="(max-width:760px) 100vw, 60vw" />
            <span className="art-caption">Form & space — Studio campaign, 2026</span>
          </div>
        </section>
        <section className="details">
          <div className="details-heading">
            <div><span className="section-label">A closer look</span><h2>NHỎ TRONG CHI TIẾT.<br />RÕ TRONG CÁ TÍNH.</h2></div>
            <p>Ba chi tiết tạo nên<br />ngôn ngữ của FORM 01.</p>
          </div>
          <div className="detail-grid">
            {details.map(item => (
              <article key={item.view}>
                <div className="detail-image macro">
                  <Image src={`/images/detail-${item.view}.webp`} alt={`Chi tiết ${item.title.toLowerCase()} của FORM 01`} width={1000} height={800} sizes="(max-width:760px) 90vw, 30vw" />
                </div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>
        <Colorways />
        <section className="signup" id="dang-ky" aria-labelledby="signup-title">
          <div className="signup-copy"><span className="section-label">Stay in the loop</span><h2 id="signup-title">BƯỚC TIẾP THEO.<br />CÓ BẠN.</h2><p>Theo dõi hành trình phát triển FORM 01.<br />Trải nghiệm biểu mẫu đăng ký của VANTA.</p></div>
          <Signup />
        </section>
      </main>
      <footer className="footer">
        <a href="#" className="footer-logo" aria-label="VANTA về đầu trang">VANTA</a>
        <div className="footer-bottom">
          <span>© 2026 VANTA Design Concept</span>
          <p>Thương hiệu và sản phẩm hư cấu. Website concept, không bán hàng hoặc thu thập email.</p>
          <a href="#">Về đầu trang ↑</a>
        </div>
      </footer>
    </>
  );
}
